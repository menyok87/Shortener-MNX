<!doctype html>
<html>
<title>Site Maintenance</title>
<style>
  body { text-align: center; padding: 150px; }
  h1 { font-size: 50px; }
  body { font: 20px Helvetica, sans-serif; color: #333; }
  article { display: block; text-align: left; width: 650px; margin: 0 auto; }
  a { color: #dc8100; text-decoration: none; }
  a:hover { color: #333; text-decoration: none; }
</style>

<article>
    <h1 style="text-align: center;border-color: black;background: #dbdbdb;padding: 0.5rem 0 0.5rem 0;border-radius: 10px;">We&rsquo;ll be back soon!</h1>
    <div>
        <p>Sorry for the inconvenience but we&rsquo;re performing some maintenance at the moment.
        </p>
         <h5 style="text-align: center;border-color: black;background: #dbdbdb40;margin: 10rem 10rem 10rem 10rem;padding: 0.5rem 0 0.5rem 0;border-radius: 10px;text-shadow: 0px 0 #fdc1c1;"><? echo $_SERVER['SERVER_NAME'];?>
        </h5>
    </div>
</article>
</html>